let d = new Date();
document.getElementById('date').value =
  'Current time: ' + d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds()