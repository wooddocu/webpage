<?php
     session_name("user2");
     session_start();
?>