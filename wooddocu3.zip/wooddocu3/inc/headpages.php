    <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link href="https://fonts.googleapis.com/css2?family=Gidugu&family=Red+Rose:wght@700&family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/pages.css">
    <link rel="stylesheet" href="../css/admin.css">
    <title>Wooddocu</title>
    
