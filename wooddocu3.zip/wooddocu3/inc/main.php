    <main>
        <div class="contenedor">
            <div class="contenedor-conciertos">
                <div class="card" style="background-image: url('./images/1_How to Make a Modern Oak Coffee Table.jpg')">
                    <div class="textos">
                        <h3>How to Make a Modern Oak Coffee Table</h3>
					                   <p>27 de Octubre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_How to Sand and Polish Epoxy Resin to a Mirror Finish.jpg')">
                    <div class="textos">
					                   <h3>How to Sand and Polish Epoxy Resin to a Mirror Finish</h3>
                        <p>12 de Noviembre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Collapsible Outdoor Chair.jpg')">
				                <div class="textos">
					                   <h3>Collapsible Outdoor Chair</h3>
					                   <p>13 de Diciembre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Making and Installing Box Joint Drawers.png')">
                    <div class="textos">
					                   <h3>Making and Installing Box Joint Drawers</h3>
					                   <p>20 de Diciembre 2021</p>
                    </div>
                </div>
			             <div class="card" style="background-image: url('./images/1_Wooden Spool Patio Table.jpg')">
                    <div class="textos">
				                    <h3>Wooden Spool Patio Table</h3>
					                   <p>27 de Diciembre 2021</p>
                    </div>
                </div>
		              <div class="card" style="background-image: url('./images/2_Wall Mounted Blanket Ladder.jpg')">
                    <div class="textos">
					                   <h3>Wall Mounted Blanket Ladder</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Foldable Stool - Reverse Engineering the Tallon Stool.jpg')">
                    <div class="textos">
					                   <h3>Foldable Stool - Reverse Engineering the Tallon Stool</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Bent Wood Floating Cabinet (One Board Contest).jpg')">
                    <div class="textos">
					                   <h3>Bent Wood Floating Cabinet (One Board Contest)</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_20$ Nightstand From Single 2x12 Lumber.jpg')">
                    <div class="textos">
					                   <h3>20$ Nightstand From Single 2x12 Lumber</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Plywood Rocking Chair Under 30$.jpg')">
                    <div class="textos">
					                   <h3>Plywood Rocking Chair Under 30$</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/2_College Loft Bed.jpg')">
                    <div class="textos">
					                   <h3>College Loft Bed</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Table From a 2 X 4 Board.png')">
                    <div class="textos">
					                   <h3>Table From a 2' X 4' Board</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Simple Round Coffee Table With 3D Printing.jpg')">
                    <div class="textos">
					                   <h3>Simple Round Coffee Table With 3D Printing</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Table Into a Ceiling Lamp.jpg')">
                    <div class="textos">
					                   <h3>Table Into a Ceiling Lamp</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_DIY Floating Bed Frame.jpg')">
                    <div class="textos">
					                   <h3>DIY Floating Bed Frame</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Modern Rolltop Desk.jpg')">
                    <div class="textos">
					                   <h3>Modern Rolltop Desk</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_Laptop Desk.jpg')">
                    <div class="textos">
					                   <h3>Laptop Desk</h3>
					                   <p>1 de Enero 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_One-Sheet Plywood Desk (Midcentury Modern).jpg')">
                    <div class="textos">
                        <h3>One-Sheet Plywood Desk (Midcentury Modern)</h3>
					                   <p>27 de Octubre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/1_One-Sheet Plywood Angled Bookshelf (Midcentury Modern).jpg')">
                    <div class="textos">
					                   <h3>One-Sheet Plywood Angled Bookshelf (Midcentury Modern)</h3>
                        <p>12 de Noviembre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/')">
				                <div class="textos">
					                   <h3></h3>
					                   <p>13 de Diciembre 2021</p>
                    </div>
                </div>
                <div class="card" style="background-image: url('./images/')">
                    <div class="textos">
					                   <h3></h3>
					                   <p>20 de Diciembre 2021</p>
                    </div>
                </div>
			             <div class="card" id="bed4" style="background-image: url('./images/')">
                    <div class="textos">
				                    <h3></h3>
					                   <p>27 de Diciembre 2021</p>
                    </div>
                </div>
            </div>
        </div>
        <iframe src = "https://www.w3schools.com" title = "Tutoriales web gratuitos en línea de W3Schools" >      
</iframe>
    </main>