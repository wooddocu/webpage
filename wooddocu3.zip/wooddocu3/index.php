<?php
require "./inc/session_start.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
include './inc/head.php';
    ?>
</head>
<body>
<?php
include './inc/header.php';
?>
<?php
include './inc/main.php';
?>
    
<script>
function myFunction() {
  document.getElementById("bed4").style.display = "none";
}
</script>
</body>
</html>
<!-- htmls y titulos copiados -->
<!-- How to Make a Modern Oak Coffee Table
https://www.instructables.com/How-to-Make-a-Modern-Oak-Coffee-Table/

How to Sand and Polish Epoxy Resin to a Mirror Finish - Step by Step Guide
https://www.instructables.com/How-to-Flat-and-Polish-Epoxy-Resin-to-a-Mirror-Fin/

Collapsible Outdoor Chair
https://www.instructables.com/Collapsible-Outdoor-Chair/

Making and Installing Box Joint Drawers
https://www.instructables.com/Making-and-Installing-Box-Joint-Drawers/

Wooden Spool Patio Table
https://www.instructables.com/Wooden-Spool-Patio-Table/

Wall Mounted Blanket Ladder
https://www.instructables.com/Wall-Mounted-Blanket-Ladder/ 

Foldable Stool - Reverse Engineering the Tallon Stool
https://www.instructables.com/Foldable-Stool-Reverse-Engineering-the-Tallon-Stoo/

Bent Wood Floating Cabinet (One Board Contest)
https://www.instructables.com/Bent-Wood-Floating-Cabinet-One-Board-Contest/

20$ Nightstand From Single 2x12 Lumber
https://www.instructables.com/20-Nightstand-From-Single-2x12-Lumber/

Plywood Rocking Chair Under 30$
https://www.instructables.com/Plywood-Rocking-Chair/

College Loft Bed
https://www.instructables.com/College-Loft-Bed/ 
DIY Workbench With Drawers
https://www.instructables.com/DIY-Workbench-With-Drawers/

Table From a 2' X 4' Board
https://www.instructables.com/Table-From-a-2-X-4-Board/

Simple Round Coffee Table With 3D Printing
https://www.instructables.com/Simple-Round-Coffee-Table-With-3D-Printing/Turning an Old Teak Coffee
 
Table Into a Ceiling Lamp
https://www.instructables.com/Turning-an-Old-Teak-Coffee-Table-Into-a-Ceiling-La/

DIY Floating Bed Frame
https://www.instructables.com/DIY-Floating-Bed-Frame/

Modern Rolltop Desk
https://www.instructables.com/Modern-Rolltop-Desk/

Laptop Desk
https://www.instructables.com/Laptop-Desk/

One-Sheet Plywood Desk (Midcentury Modern)
https://www.instructables.com/One-Sheet-Plywood-Desk-Midcentury-Modern/

One-Sheet Plywood Angled Bookshelf (Midcentury Modern)
https://www.instructables.com/One-Sheet-Plywood-Angled-Bookshelf-Midcentury-Mode/-->






            
    
    
