<!DOCTYPE html>
<html lang="en">
<head>
<?php include './inc/headpages.php'; ?>
</head>
<body>
    <?php include './inc/headerpages.php'; ?>
    <main>
        <img class="cover" src="/storage/emulated/0/Pictures/ImageDownloaderApp/How to Sand and Polish Epoxy Resin to a Mirror Finish - Step by Step Guide  5 Steps (with Pictures) - Instructables/1howtosand.jpg" alt="">
        <img class="cover" src="/storage/emulated/0/Pictures/AllPic/instructables.com_How to Sand and Polish Epoxy Resin to a Mirror Finish - Step by Step Guide _ 5 Steps (with Pictures) - Instructables_5cfcdeba/How to Sand and Polish Epoxy Resin to a Mirror Finish - Step by Step Guide _ 5 Steps (with Pictures) - Instructables/6_How to Sand and Polish Epoxy Resin to a Mirror Finish - Step by Step Guide _ 5 Steps (with Pictures) - Instructables.jpg" alt="">
        <!-- <iframe></iframe> -->
   <!-- <video src="" type="video/mp4" poster="" controls> Tu navegador no admite el elemento <code>video</code>. </video> -->
        <h1>Making and Installing Box Joint Drawers
By TheGrantAlexander</h1>
        <h2></h2>
        <p></p>
        <h2></h2>
        <p></p>
    </main>
</body>
</html>
