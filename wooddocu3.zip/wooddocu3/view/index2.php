<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link href="https://fonts.googleapis.com/css2?family=Gidugu&family=Red+Rose:wght@700&family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/style2.css">
    <!--<link rel="stylesheet" href="./css/admin.css">-->
    <title>Wooddocu</title>      
</head>
<header>
        <a class="a_logo" href="index.php">
        <img class="logo" src="./images/menu/Wooddoculogopages.png" alt="Wooddocu">
        </a>
        <nav>
          
           <input class="button" type="checkbox" id="button">
           <label for="button"class="bar">
                     <span class="top"></span>
                     <span class="middle"></span>
                     <span class="bottom"></span>
                     <span class="menu">Menu</span>
                     <span class="close">Close</span>                                                            
           </label>          
           <label for="button"></label>   
           <div class="list">                                                                                                                                         
            <ul class="a" class="links_menus">
            		<li style="background-image: url('./images/menu/coffeetablequeenanne.jpeg')"><a class="a_menu" href="#">Coffee tables</a></li>
            		<li style="background-image: url('./images/menu/Bed_6.jpg')"><a class="a_menu" href="#">Beds</a></li>
            		<li style="background-image: url('./images/menu/Nightstand_7.jpg');"><a class="a_menu" href="#">Night stand</a></li>
            		<li style="background-image: url('./images/menu/Table_2.jpg');"><a class="a_menu" href="#">Tables</a></li>
            	 <li style="background-image: url('./images/menu/Drawers_1.jpg');"><a class="a_menu" href="#">Drawers</a></li>
            	 <li style="background-image: url('./images/menu/Chair_6.jpg');"><a class="a_menu" href="#">Chairs</a></li>
            	 <li style="background-image: url('./images/menu/Cabinet_1.png');"><a class="a_menu" href="#">Cabinets</a></li>
            	 <li style="background-image: url('./images/menu/Utensil_1.jpg');"><a class="a_menu" href="#">Utensils</a></li>
            </ul>
            <ul class="b">
            	 <li style="background-image: url('./images/menu/Carpentry_1.jpg');"><a class="a_menu" href="#">Carpentry</a></li>           
            	 <li style="background-image: url('./images/menu/Sofa_1.jpg');"><a class="a_menu" href="#">Sofas</a></li>
            	 <li style="background-image: url('./images/menu/Desk_1.jpeg');"><a class="a_menu" href="#">Desk</a></li>
            	 <li style="background-image: url('./images/menu/Question_1.jpg')"><a class="a_menu" href="#">Questions</a></li>
            	 <li style="background-image: url('./images/menu/Technique_1.jpg')"><a class="a_menu" href="#">Techniques</a></li>
            	 <li style="background-image: url('./images/menu/Craft_1.jpg')"><a class="a_menu" href="#">Crafts</a></li>
            	 <li style="background-image: url('./images/menu/Design_2.jpg')"><a class="a_menu" href="#">Designs</a></li>         
            </ul>                          
           </div>                                        
        </nav>
    </header>
    <form action="./php/send_test.php" method="post" accept-charset="utf-8">
        <input name="input_send_test"type="text">
        <button type="submit">Send test</button>
    </form>
        
    </form>
<body>
    
</body>
</html>