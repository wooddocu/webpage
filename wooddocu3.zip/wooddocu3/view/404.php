<a href="" class="fa fa-arrow-left"></a>
<div class="error">
  <h1 class="h1_404">404</h1>
  <p class="p_404">Page not found</p>
 <!-- <input placeholder="Try searching for what you were looking for..."></input><button></button>-->
</div>      
        
        
        
        <!--- <div class="containerlogin">
                <form action="#" method="post" class="loginboxs">
                    <input type="text" placeholder="E-mail" class="login" required>
                    <input type="text" placeholder="Password" class="login password" required>
                    <button type="submit" class="button login">Login</button>               
                </form>
            </div> ---->    